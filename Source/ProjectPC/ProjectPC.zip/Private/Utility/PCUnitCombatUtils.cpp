#include "Utility/PCUnitCombatUtils.h"

const FIntPoint PCUnitCombatUtils::Directions[6] = {
	{ -1,1}, {0, 1},
	{ -1, 0}, { 1,0},
	{ -1, -1}, { 0, -1}
};